# 🚀 Quick Deployment Guide

Follow these steps to deploy your portfolio to GitHub and Vercel.

## Step 1: Initialize Git & GitHub

### 1.1 Create Repository on GitHub
1. Go to [github.com/new](https://github.com/new)
2. Repository name: `thierry-portfolio`
3. Description: "Professional portfolio - Payment technology leader"
4. Make it **Public** (better for portfolio)
5. Click "Create repository"

### 1.2 Initialize Local Repository
```bash
# Navigate to your project folder
cd /path/to/thierry-portfolio

# Initialize git
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Animated portfolio with React, Vite, Framer Motion"

# Add remote
git branch -M main
git remote add origin https://github.com/thierry0303/thierry-portfolio.git

# Push to GitHub
git push -u origin main
```

## Step 2: Deploy to Vercel

### 2.1 Create Vercel Account
1. Go to [vercel.com](https://vercel.com)
2. Sign up with GitHub (easiest option)
3. Authorize Vercel to access your GitHub account

### 2.2 Create New Project
1. Click "New Project"
2. Select `thierry-portfolio` from your repositories
3. Keep default settings:
   - **Framework Preset**: Vite
   - **Root Directory**: ./
   - **Build Command**: `npm run build` (auto-detected)
   - **Output Directory**: `dist` (auto-detected)
4. Click "Deploy"
5. Wait 2-3 minutes for deployment ✅

### 2.3 Add Custom Domain (Optional)
1. In Vercel Dashboard → Project Settings
2. Click "Domains"
3. Enter your domain (e.g., `thierryamiot.com`)
4. Follow DNS instructions from your domain provider

## Step 3: GitHub URLs

Your GitHub repo will be at:
```
https://github.com/thierry0303/thierry-portfolio
```

Your portfolio will be live at:
```
https://thierry-portfolio.vercel.app
# or your custom domain
https://thierryamiot.com
```

## Step 4: Verify Everything

- [ ] GitHub repo created with all files
- [ ] Vercel deployment successful
- [ ] Portfolio loads on custom URL
- [ ] All animations working
- [ ] CV download button works
- [ ] Footer buttons functional
- [ ] Mobile responsive

## 🔄 Making Updates

After deployment, any changes are super easy:

```bash
# Make changes to src/App.jsx, tailwind.config.js, etc.

# Commit changes
git add .
git commit -m "Update: Added new project"

# Push to GitHub
git push origin main

# Vercel automatically redeploys! ✅
```

## 📊 Monitoring

Check deployment status:
1. Go to [vercel.com/dashboard](https://vercel.com/dashboard)
2. Click `thierry-portfolio`
3. View deployments and logs
4. Check performance analytics

## ⚡ Performance

Your portfolio will have:
- **Automatic optimization** by Vercel
- **Global CDN** distribution
- **Instant deployments** on git push
- **Free HTTPS** certificate

## 🆘 Troubleshooting

### Build fails
```bash
# Clear cache and rebuild
rm -rf node_modules
npm install
npm run build
```

### Port already in use
```bash
# Use different port
npm run dev -- --port 3001
```

### Vercel deployment stuck
1. Check build logs in Vercel dashboard
2. Verify `package.json` scripts
3. Ensure no missing dependencies

## 💡 Pro Tips

1. **Add GitHub Badge** to README
```markdown
[![Vercel](https://vercel.com/button)](https://vercel.com/import/project?template=https://github.com/thierry0303/thierry-portfolio)
```

2. **Enable Analytics** in Vercel dashboard (free)

3. **Set up Email** notifications for deployments

4. **Use GitHub Actions** for CI/CD (advanced)

---

**Questions?** Check the main README.md or Vercel/GitHub docs!
