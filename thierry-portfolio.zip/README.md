# Thierry Amiot - Professional Portfolio

A modern, animated React portfolio showcasing payment technology expertise, projects, and professional achievements.

## 🚀 Features

- **Responsive Design** - Works perfectly on mobile, tablet, and desktop
- **Smooth Animations** - Framer Motion animations for engaging interactions
- **Professional Layout** - Clean, modern design with dark theme
- **Fast Performance** - Built with Vite for optimal load times
- **SEO Optimized** - Meta tags and semantic HTML
- **Accessibility** - WCAG compliant with proper ARIA labels

## 🛠️ Tech Stack

- **React 18** - UI framework
- **Vite** - Build tool & dev server
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Animation library
- **Lucide React** - Icon library
- **Vercel** - Deployment platform

## 📦 Installation

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Setup

1. **Clone the repository**
```bash
git clone https://github.com/thierry0303/thierry-portfolio.git
cd thierry-portfolio
```

2. **Install dependencies**
```bash
npm install
```

3. **Start development server**
```bash
npm run dev
```

The site will open at `http://localhost:3000`

## 🏗️ Project Structure

```
thierry-portfolio/
├── src/
│   ├── App.jsx           # Main portfolio component
│   ├── main.jsx          # React entry point
│   └── index.css         # Global styles & Tailwind
├── index.html            # HTML template
├── package.json          # Dependencies
├── vite.config.js        # Vite configuration
├── tailwind.config.js    # Tailwind configuration
├── postcss.config.js     # PostCSS configuration
├── vercel.json           # Vercel deployment config
└── README.md             # This file
```

## 🎨 Customization

### Update Your Information

Edit `src/App.jsx` and update:
- **Hero section** - Title, description
- **Projects** - Add/remove your projects
- **Skills** - Update expertise areas
- **Experience** - Add work history
- **Academic** - Update education
- **Contact** - Update email/links

### Styling

Tailwind CSS is pre-configured. Customize colors in `tailwind.config.js`:

```javascript
theme: {
  extend: {
    colors: {
      amber: {
        300: '#fcd34d',
        400: '#fbbf24',
      },
      // Add more colors...
    }
  }
}
```

## 🚀 Deployment

### Deploy to Vercel (Recommended)

1. **Push to GitHub**
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Select your GitHub repository
   - Click "Deploy"
   - Vercel will automatically build and deploy!

### Custom Domain

1. In Vercel Dashboard: Settings → Domains
2. Add your custom domain (e.g., thierryamiot.com)
3. Follow DNS configuration instructions

### Deploy Locally

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## 📊 Building for Production

```bash
npm run build
```

This creates optimized files in the `dist/` folder ready for deployment.

## 🔒 Environment Variables

Create a `.env.local` file for any sensitive data:

```
VITE_API_URL=https://api.example.com
VITE_GA_ID=your-google-analytics-id
```

## 📝 License

This project is open source and available under the MIT License.

## 👤 About

**Thierry Amiot** - Payment Technology Leader  
- 13+ years in card payments & fintech
- CSM at Outseer (RSA Security)
- Entrepreneur (London directories)
- MSc Blockchain research (Birkbeck)

**Links:**
- [LinkedIn](https://linkedin.com/in/thierry-amiot-b92a7437)
- [GitHub](https://github.com/thierry0303)
- [Email](mailto:thierry1981@protonmail.com)

## 🤝 Contributing

Found an issue? Have suggestions? Open an issue or submit a PR!

---

Made with ❤️ by Thierry Amiot
